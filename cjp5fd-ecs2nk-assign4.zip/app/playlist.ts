export class Playlist {
	createrID: number;
	numSongs: number;
	genre: string;
	playListID: number;
}