export class Account {
    constructor (
        public user: string,
        public pwd: string,
        public pwd2: string
    ){}
       

}
