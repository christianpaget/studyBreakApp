import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-create-success',
  templateUrl: './create-success.component.html',
  styleUrls: ['./create-success.component.css']
})
export class CreateSuccessComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
