export class User{
	playlistID: number;
	step1search: String;
	step2search: String;
	studytime: number;
	breaktime: number;

}
