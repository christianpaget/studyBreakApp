import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-user-playlists',
  templateUrl: './user-playlists.component.html',
  styleUrls: ['./user-playlists.component.css']
})
export class UserPlaylistsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
