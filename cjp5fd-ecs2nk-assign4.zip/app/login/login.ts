export class login{
	constructor(
		public username: string,
		public password: string
		){}
}