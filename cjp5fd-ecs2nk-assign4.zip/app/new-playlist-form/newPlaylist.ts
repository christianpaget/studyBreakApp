export class newPlaylist{
	constructor(
		public step1choice: string,
		public step1search: string,
		public step2choice: string,
		public step2search: string,
		public studytime: number,
		public breaktime: number,
		public playlistID: number,
		public userID: string
		){}
}